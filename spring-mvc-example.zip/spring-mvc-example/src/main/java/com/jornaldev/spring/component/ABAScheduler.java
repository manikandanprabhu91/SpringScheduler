package com.jornaldev.spring.component;

import org.springframework.stereotype.Component;

@Component("abaScheduler")
public class ABAScheduler {

	public void printMessage() {
        System.out.println("ABA Service is calling Filenet server........");
    }
	
}
